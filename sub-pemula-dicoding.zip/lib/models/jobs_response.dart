class Restaurant {
  String restoName;
  String location;
  String price;
  String restoGambar;
  bool savedResto;

  Restaurant(
      {required this.restoName,
      required this.location,
      required this.price,
      required this.restoGambar,
      required this.savedResto});
}
