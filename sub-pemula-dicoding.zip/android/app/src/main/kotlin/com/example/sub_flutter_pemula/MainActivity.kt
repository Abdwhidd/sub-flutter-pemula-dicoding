package com.example.sub_flutter_pemula

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
